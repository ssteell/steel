/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;

/**
 *
 * @author usci
 */
public class Purse {
    ArrayList<String> purse = new ArrayList();
    public void addCoin(String coin){
        purse.add(coin);
    }
    public String toString(){
        System.out.println(purse);
        return null;
    }
    public ArrayList<String> reverse(){
        for (int i = 0; i < purse.size())
    
}
