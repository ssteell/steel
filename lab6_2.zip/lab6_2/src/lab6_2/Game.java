/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;

/**
 *
 * @author usci
 */
public class Game {
    private int you;
    Random com = new Random(3);
    public void play() {
        if (you == 0){
            if (com == 0) {
                
            }
            
        }
    }
}
