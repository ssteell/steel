/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author usci
 */
public class CannonBall {
    private double initV,simS,simT;
    public static final double g = 9.81;
    public CannonBall(double ball){
        initV = ball;
    }
    public void simulatedFlight() {
        for(double t = 0.01; initV > 0; t += 0.01){
             double s = initV*t;
             simS = simS + s;
             initV = initV - g*t;
             simT = t;
             if (simT != 1) {
        } else {
                 System.out.println(simS);
            }
             
         }    
    }
}    
    
    
    
    

