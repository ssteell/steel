/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicsquare;

import java.util.Scanner;

/**
 *
 * @author usci
 */
public class MagicSquareTester {
    private int n=1;
    public static void main(String[] args) {
        while (n%2 != 0){    
            System.out.print("Enter size: ");
            Scanner n = new Scanner(System.in);
            
        }
        int N = n.nextInt();
        MagicSquare test = new MagicSquare(N);

    }
}